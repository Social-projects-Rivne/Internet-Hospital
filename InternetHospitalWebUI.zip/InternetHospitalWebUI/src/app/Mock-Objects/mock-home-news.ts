import { HomeImages } from "../Models/Temp/HomeImage";


export const HOME_IMAGES: HomeImages[] = [
    {id: 1, title: 'New Jersey Favorite Dentist', url: 'https://cdn.vortala.com/static/uploads/8/files/2017/10/midland-park-dental.jpg'},
    {id: 2, title: 'Trust dental group', url: 'https://cdn.vortala.com/static/uploads/8/files/2018/06/trust-dental-group.jpg'},
    {id: 3, title: 'Sea Part dental', url: 'https://cdn.vortala.com/static/uploads/8/files/2018/06/seaport-dental.jpg'},
    {id: 4, title: 'Red Hill Dental', url: 'https://cdn.vortala.com/static/uploads/8/files/2018/06/red-hill-dental.jpg'},
    {id: 5, title: 'FocusOrthodontics', url: 'https://cdn.vortala.com/static/uploads/8/files/2018/06/focus-orthodontics.jpg'},
    {id: 6, title: 'Green Apple Dental Clinic', url: 'https://cdn.vortala.com/static/uploads/8/files/2018/06/green-apple-dental.jpg'},
  ];