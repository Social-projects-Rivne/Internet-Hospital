import { Component, OnInit } from '@angular/core';
import { CONTENTS_MNG, MODERATORS_MNG, REQUESTS_MNG, USERS_MNG } from '../routesConfig';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {

  users = "[/" + USERS_MNG + "]";
  contents = "[/" + CONTENTS_MNG + "]";
  moders = "[/" + MODERATORS_MNG + "]";
  request = "[/" + REQUESTS_MNG + "]";

  constructor() { }

  ngOnInit() {
  }

}
