import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-content-preview',
  templateUrl: './content-preview.component.html',
  styleUrls: ['./content-preview.component.scss']
})
export class ContentPreviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
