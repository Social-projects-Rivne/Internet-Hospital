export const MODERATORS_MNG = "moders";
export const USERS_MNG = "users";
export const REQUESTS_MNG = "requests";
export const CONTENTS_MNG = "contents";
export const MODER_CREATE = "createmod";