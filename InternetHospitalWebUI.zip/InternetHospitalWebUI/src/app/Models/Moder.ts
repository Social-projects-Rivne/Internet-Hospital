export class Moder {
    Id: number;
    Email: string;
    Name: string;
    Surname: string;
    Lastname: string;
    Password: string;
    ConfirmPassword: string;
}