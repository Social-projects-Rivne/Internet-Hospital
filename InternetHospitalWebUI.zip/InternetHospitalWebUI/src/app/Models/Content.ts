export class Content {
    Id: number;
    Title: string;
    Body: string;
    Source: string;
    Images: string[];
}