export class HomeImages {
    id: number;
    title: string;
    url: string;
}