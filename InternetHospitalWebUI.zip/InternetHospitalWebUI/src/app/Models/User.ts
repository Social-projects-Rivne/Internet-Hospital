export class User {
    Id: number;
    Email: string;
    Password: string;
    ConfirmPassword: string;
    Role: string;
    Image: FormData;
}