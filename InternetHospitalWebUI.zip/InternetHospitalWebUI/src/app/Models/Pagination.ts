export class Pagination {
    pageSize = 4;
    pageIndex = 1;
    allItemsLength = 0;
}