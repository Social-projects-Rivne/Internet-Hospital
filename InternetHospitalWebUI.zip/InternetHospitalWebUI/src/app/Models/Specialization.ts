export class Specialization {
    id: number;
    specialization: string;
}