export class Doctor {
    id: number;
    firstName: string;
    secondName: string;
    thirdName: string;
    avatarUrl: string;
    specialization: string;
}